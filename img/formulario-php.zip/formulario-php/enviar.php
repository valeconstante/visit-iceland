<?php
$pagina = "http://www.dominioejemplo.com/gracias.html";
Header("Location: $pagina");
?>
<?php
$para = 'correo@ejemplo.com';
$asunto = 'Mensaje desde la web';
$nombre = $_POST['nombre'];
$mail = $_POST['mail'];
$mensaje = $_POST['mensaje'];
$contenido = "Este mensaje fue enviado por " . $nombre . " \r\n";
$contenido .= "Su e-mail es: " . $mail . " \r\n";
$contenido .= "Su mensaje es: " . $mensaje . " \r\n";
mail($para, $asunto, $contenido);
?>
